/**
 * Service layer beans.
 */
package com.dalanbank.app.service;
