/**
 * Data Transfer Objects.
 */
package com.dalanbank.app.service.dto;
