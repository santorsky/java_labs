/**
 * JPA domain objects.
 */
package com.dalanbank.app.domain;
