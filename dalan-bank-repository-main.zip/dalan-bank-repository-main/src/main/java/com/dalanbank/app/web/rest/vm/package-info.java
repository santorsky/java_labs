/**
 * View Models used by Spring MVC REST controllers.
 */
package com.dalanbank.app.web.rest.vm;
