/**
 * Spring Data JPA repositories.
 */
package com.dalanbank.app.repository;
